import { useEffect, useState } from 'react'

import { motion } from 'framer-motion'

import { ArrowDown, ArrowRight, ArrowUpRight, Atom, Beaker, BookOpen, Brain, Calculator, ClipboardCheck, FileText, Check, ChevronDown, ChevronLeft, ChevronRight, CircleHelp, FlaskConical, GraduationCap, Instagram, Lightbulb, Menu, Microscope, Play, Send, Sparkles, Target, Users, X, Youtube, Facebook, MapPin, Phone, MessageCircle, Mail, Clock3, Quote, CheckCircle2 } from 'lucide-react'

import { institute } from './config/instituteConfig'

import { courses } from './data/courses'

import { achievements } from './data/achievements'



const ease = [0.22, 1, 0.36, 1]

const fadeUp = { hidden: { opacity: 0, y: 26 }, visible: { opacity: 1, y: 0, transition: { duration: 0.65, ease } } }

const reveal = { initial: 'hidden', whileInView: 'visible', viewport: { once: true, amount: 0.15 }, variants: fadeUp }

const navLinks = [['Home', '#home'], ['About Us', '#about'], ['Our Courses', '#courses'], ['Our Faculty', '#faculty'], ['Our Achievements', '#achievements'], ['Contact Us', '#contact']]



function Brand({ light = false }) {

  return (

    <a

      className={`brand ${light ? 'brand-light' : ''}`}

      href="#home"

      aria-label="Kota Chemistry Gaya home"

    >

      <img

        className="brand-logo"

        src="/Kota_chem_logo.jpeg"

        alt="Kota Chemistry logo"

      />

      <span className="brand-wordmark">

        <strong>KOTA CHEMISTRY GAYA</strong>

        <small>BY RP YADAW SIR</small>

         <small>No.01 Chemistry Coaching in Gaya</small>

      </span>

    </a>

  );

}



function SocialLinks({ light = false }) {

  const items = [

    ['facebook', Facebook, 'Facebook'], ['instagram', Instagram, 'Instagram'], ['youtube', Youtube, 'YouTube'], ['telegram', Send, 'Telegram'],

  ]

  return <div className={`social-links ${light ? 'social-light' : ''}`}>{items.map(([key, Icon, label]) => institute.socials[key] ? <a key={key} href={institute.socials[key]} target="_blank" rel="noreferrer" aria-label={label}><Icon size={17} /></a> : <span className="social-inactive" key={key} aria-label={`${label} URL not configured`} title={`${label} link can be added in instituteConfig.js`}><Icon size={17} /></span>)}</div>

}



function Navbar() {

  const [scrolled, setScrolled] = useState(false)

  const [menuOpen, setMenuOpen] = useState(false)

  const [active, setActive] = useState('#home')

  useEffect(() => {

    const onScroll = () => { setScrolled(window.scrollY > 20); const section = [...document.querySelectorAll('main section[id]')].reverse().find(el => window.scrollY >= el.offsetTop - 150); setActive(section ? `#${section.id}` : '#home') }

    window.addEventListener('scroll', onScroll, { passive: true }); onScroll(); return () => window.removeEventListener('scroll', onScroll)

  }, [])

  const close = () => setMenuOpen(false)

  return <header className={`site-header ${scrolled ? 'is-scrolled' : ''}`}><div className="nav-shell"><Brand /><nav className={`nav-links ${menuOpen ? 'nav-open' : ''}`} aria-label="Main navigation">{navLinks.map(([label, href]) => <a key={href} className={active === href ? 'nav-active' : ''} href={href} onClick={close}>{label}</a>)}<a href="#contact" className="button button-gold nav-cta" onClick={close}>Enquire Now <ArrowUpRight size={15} /></a></nav><button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen}>{menuOpen ? <X /> : <Menu />}</button></div></header>

}



function Eyebrow({ children, light = false }) { return <div className={`eyebrow ${light ? 'eyebrow-light' : ''}`}><span />{children}</div> }



function MolecularVisual() {

  return <div className="hero-visual" aria-label="Illustration of chemistry molecules and laboratory equipment" role="img"><div className="visual-orbit orbit-one"/><div className="visual-orbit orbit-two"/><div className="atom-core"><Atom size={78} strokeWidth={1.2} /><span className="atom-orbit-dot dot-one"/><span className="atom-orbit-dot dot-two"/></div><div className="floating-chip chip-chem"><Beaker size={15} /> CHEMISTRY</div><div className="floating-chip chip-formula">H<sub>2</sub>O <span>+ clarity</span></div><div className="floating-chip chip-result"><span className="chip-dot"/> Concepts<br/><b>made clear</b></div><div className="lab-card"><div className="lab-card-top"><span>ELEMENTS OF SUCCESS</span><span className="lab-dots">•••</span></div><div className="periodic"><div className="element element-blue"><small>01</small><b>H</b><span>Hydrogen</span></div><div className="element element-gold"><small>08</small><b>O</b><span>Oxygen</span></div><div className="element element-pale"><small>11</small><b>Na</b><span>Sodium</span></div><div className="element element-mint"><small>17</small><b>Cl</b><span>Chlorine</span></div></div><div className="lab-card-bottom"><span><i/> Curiosity meets understanding</span><ArrowUpRight size={15}/></div></div><div className="hero-stamp"><Sparkles size={14}/><span>LEARN<br/>CURIOUSLY</span></div></div>

}



function Hero() {

  return <section className="hero" id="home"><div className="hero-grid-bg"/><div className="hero-inner"><motion.div className="hero-copy" initial="hidden" animate="visible" variants={{ visible: { transition: { staggerChildren: 0.13 } } }}><motion.div variants={fadeUp}><Eyebrow light>KOTA CHEMISTRY BY RP YADAW SIR</Eyebrow></motion.div><motion.h1 variants={fadeUp}>Make Chemistry<br/><span>Easy, Interesting</span><br/><em>& Conceptual.</em></motion.h1><motion.p className="hero-subheading" variants={fadeUp}>Understand Chemistry. <strong>Build Confidence.</strong><br/>Achieve Excellence.</motion.p><motion.p className="hero-description" variants={fadeUp}>Learn Chemistry from basics to advanced concepts with structured teaching, regular practice, doubt-clearing support and academic guidance at our Gaya branches.</motion.p><motion.div className="hero-actions" variants={fadeUp}><a className="button button-gold" href="#courses">Explore Our Courses <ArrowRight size={16}/></a><a className="button button-outline" href="#contact">Contact Us <ArrowUpRight size={16}/></a></motion.div><motion.div className="hero-note" variants={fadeUp}><div className="note-icon"><Lightbulb size={17}/></div><span>A thoughtful approach to<br/><b>learning chemistry well.</b></span><span className="note-line"/></motion.div></motion.div><motion.div className="hero-art-wrap" initial={{opacity:0,scale:.96,x:24}} animate={{opacity:1,scale:1,x:0}} transition={{duration:.9,ease}}><MolecularVisual/></motion.div></div><div className="hero-bottom"><span><span className="hero-bottom-dot"/> BUILD YOUR FOUNDATION, ONE CONCEPT AT A TIME</span><a href="#about">SCROLL TO EXPLORE <ArrowDown size={13}/></a></div></section>

}



function SectionHeading({ eyebrow, title, description, align = 'left', light = false }) {

  return <motion.div className={`section-heading align-${align} ${light ? 'heading-light' : ''}`} {...reveal}><Eyebrow light={light}>{eyebrow}</Eyebrow><h2>{title}</h2>{description && <p>{description}</p>}</motion.div>

}





function About() {

  const learningFacilities = [

    {

      icon: <BookOpen size={20} />,

      title: "Chapter-wise Study Notes",

      description: "Well-organized notes, important formulas, reactions and key concepts for easy revision."

    },

    {

      icon: <FileText size={20} />,

      title: "Board Exam Question Papers",

      description: "Previous-year question papers, sample papers and important practice questions for board exam preparation."

    },

    {

      icon: <ClipboardCheck size={20} />,

      title: "Regular Tests",

      description: "Topic-wise and chapter-wise tests to evaluate preparation and track student progress."

    },

    {

      icon: <Brain size={20} />,

      title: "Quiz & Practice Sessions",

      description: "Interactive quizzes and MCQ practice to improve knowledge, accuracy and confidence."

    },

    {

      icon: <Calculator size={20} />,

      title: "Numerical Practice",

      description: "Step-by-step numerical problem solving to strengthen Chemistry fundamentals."

    },

    {

      icon: <MessageCircle size={20} />,

      title: "Doubt-Solving Support",

      description: "Get guidance to clear doubts and understand difficult topics more effectively."

    }

  ];



  return (

    <section className="about-section section-pad" id="about">

      <div className="container">

        <div className="about-layout">



          <motion.div className="about-art" {...reveal}>

            <div className="about-art-bg">

              <div className="art-grid" />

              <div className="art-ring ring-a" />

              <div className="art-ring ring-b" />



              <div className="book-illustration">

                <div className="book-page page-left">

                  <span className="page-label">CHEMISTRY</span>

                  <div className="page-molecule">

                    <span /><span /><span /><i /><i />

                  </div>

                  <div className="page-lines">

                    <i /><i /><i />

                  </div>

                </div>



                <div className="book-page page-right">

                  <span className="page-label">LET'S EXPLORE</span>

                  <div className="page-formula">

                    Na<sub>+</sub><span>+</span>Cl<sub>−</sub>

                  </div>

                  <div className="page-lines">

                    <i /><i /><i />

                  </div>

                  <div className="page-glow" />

                </div>

              </div>



              <div className="about-badge">

                <span className="badge-orbit"><Atom size={25} /></span>

                <span>SCIENCE<br /><b>MADE CLEAR</b></span>

              </div>



              <div className="about-art-caption">

                <Sparkles size={15} /> Curious minds, welcome.

              </div>



              <span className="art-spark spark-a">✳</span>

              <span className="art-spark spark-b">✦</span>

            </div>

          </motion.div>



          <div className="about-copy">

            <Eyebrow>A PLACE TO LEARN AND GROW</Eyebrow>



            <h2>

              Big ideas begin<br />

              with <span>clear concepts.</span>

            </h2>



            <p className="about-lead">

              Welcome to Kota Chemistry Gaya, led by RP Yadaw Sir.

              We aim to make Chemistry simple, interesting and understandable

              through concept-based teaching, quality study materials and

              regular academic practice.

            </p>



            <p>

              We focus on strong fundamentals, conceptual clarity,

              systematic learning, numerical practice and regular assessment.

              Our goal is to help students understand the logic behind every

              reaction, formula and concept while preparing confidently for

              their examinations.

            </p>



            <div className="about-points">

              <div>

                <span><Check size={15} /></span>

                <p>

                  <b>Learn with understanding</b>

                  <small>Concepts explained with clarity.</small>

                </p>

              </div>



              <div>

                <span><Check size={15} /></span>

                <p>

                  <b>Practice with purpose</b>

                  <small>Regular learning and problem solving.</small>

                </p>

              </div>



              <div>

                <span><Check size={15} /></span>

                <p>

                  <b>Get support as you learn</b>

                  <small>Student-focused teaching and doubt solving.</small>

                </p>

              </div>

            </div>



            <a className="text-link" href="#courses">

              Discover how we teach <ArrowRight size={15} />

            </a>

          </div>

        </div>



        {/* Learning Facilities */}

        <div className="learning-facilities">

          <div className="facilities-heading">

            <Eyebrow>OUR LEARNING SUPPORT</Eyebrow>

            <h2>Everything You Need to <span>Learn Better</span></h2>

            <p>

              Quality learning resources and regular practice to help

              students prepare with confidence.

            </p>

          </div>



          <div className="facilities-grid">

            {learningFacilities.map((item, index) => (

              <motion.div

                className="facility-card"

                key={item.title}

                {...reveal}

                transition={{ delay: index * 0.08 }}

              >

                <div className="facility-icon">{item.icon}</div>

                <h3>{item.title}</h3>

                <p>{item.description}</p>

              </motion.div>

            ))}

          </div>

        </div>



        {/* Branch Locations */}

        <div className="about-branches">

          <h3>Our Branch Locations – Kota Chemistry Gaya</h3>

          <div className="about-branch-list">

            <p>

              <MapPin size={17} />

              <span><b>Main Office (1st Branch):</b> Opposite Gaya College,

              in front of Rampur Police Station, Gaya, Bihar.</span>

            </p>

            <p>

              <MapPin size={17} />

              <span><b>2nd Branch:</b> Near SBI Bank, Delha Bus Stand,

              Gaya, Bihar.</span>

            </p>

            <p>

              <MapPin size={17} />

              <span><b>3rd Branch:</b> PR Palace, near Shyam Talkies,

              Manpur, Gaya, Bihar.</span>

            </p>

          </div>

        </div>



      </div>

    </section>

  );

}





function Faculty() {

  return (

    <section className="faculty-section section-pad" id="faculty">

      <div className="container">

        <SectionHeading

          eyebrow="MEET YOUR FACULTY"

          title={<>Learn with <span>RP Yadaw Sir.</span></>}

          description="Concept-based Chemistry learning with clear explanations and systematic academic preparation."

          align="center"

        />



        <motion.div className="faculty-card" {...reveal}>

          <div className="faculty-photo-wrap">

            <img

              src="/Kota_sir_photo.jpeg"

              alt="RP Yadaw Sir - Chemistry Faculty at Kota Chemistry Gaya"

              className="faculty-photo"

            />

          </div>



          <h3>RP Yadaw Sir</h3>

          <span className="faculty-role">

            Founder & Chemistry Faculty · Kota Chemistry Gaya

          </span>



          <p>

            Learn Chemistry through clear explanations,

            concept-based teaching, numerical practice

            and systematic exam preparation.

          </p>

        </motion.div>

      </div>

    </section>

  );

}





const courseIcons = [FlaskConical, BookOpen, Atom, Microscope, GraduationCap, Target]

function Courses() {

  return <section className="courses-section section-pad" id="courses"><div className="container"><SectionHeading eyebrow="LEARN WITH PURPOSE" title={<>A course for every <span>next step.</span></>} description="Build understanding, strengthen your practice and move ahead with a learning path that fits your goals."/><div className="courses-grid">{courses.map((course, i) => { const Icon = courseIcons[i % courseIcons.length]; return <motion.article className="course-card" key={course.title} {...reveal} transition={{ duration: .55, delay: i * .055, ease }}><div className="course-card-top"><div className={`course-icon course-icon-${i % 3}`}><Icon size={20}/></div><span className="course-label">{course.label}</span><span className="course-symbol">{course.icon}</span></div><h3>{course.title}</h3><p>{course.description}</p><ul>{course.benefits.map(b => <li key={b}><Check size={13}/>{b}</li>)}</ul><a href="#contact" onClick={e => { e.preventDefault(); window.dispatchEvent(new CustomEvent('select-course', { detail: course.title })); document.querySelector('#contact')?.scrollIntoView({behavior:'smooth'}) }} className="course-link">Enquire about this course <ArrowRight size={15}/></a></motion.article> })}</div><motion.div className="courses-footnote" {...reveal}><span className="footnote-icon"><CircleHelp size={18}/></span><span>Not sure where to start? <b>Tell us what you're looking for.</b> We'll help you explore the right course.</span><a href="#contact">Talk to us <ArrowUpRight size={15}/></a></motion.div></div></section>

}







function Achievements() {

  const photos = [

    "Achivement1.png",

    "Achivement2.png",

    "Achivement3.png",

    "Achivement4.png",

    "Achivement5.png",

    "Achivement6.jpeg",

    "Achivement7.png",

  ];



  return (

    <section className="achievements-section section-pad" id="achievements">

      <div className="container">



        <SectionHeading

          eyebrow="OUR STUDENTS, OUR PRIDE"

          title={<>Our Students <span>Achievements</span></>}

          description="Celebrating success, hard work and memorable moments."

          align="center"

        />



        {/* SINGLE GALLERY BOX */}

        <div className="achievement-main-box">



          <div className="achievement-grid">

            {photos.map((photo, index) => (

              <a

                href={`/${photo}`}

                target="_blank"

                rel="noreferrer"

                key={photo}

                className="achievement-image"

              >

                <img

                  src={`/${photo}`}

                  alt={`Kota Chemistry Achievement ${index + 1}`}

                  loading="lazy"

                />

              </a>

            ))}

          </div>



          <div className="achievement-bottom">

            <span>More Student Success Stories</span>



            <a

              href="https://www.facebook.com/share/1CeWcSELn9/"

              target="_blank"

              rel="noopener noreferrer"

              className="button button-blue"

            >

              <Facebook size={17} />

              Follow on Facebook

              <ArrowUpRight size={16} />

            </a>

          </div>



        </div>

      </div>

    </section>

  );

}





const features = [

  [Lightbulb, 'Concept-Based Learning', 'Make sense of the ideas behind every reaction, formula and topic.'],

  [BookOpen, 'Thoughtful Teaching', 'A clear, student-focused approach that meets learners where they are.'],

  [Target, 'Regular Practice', 'Build familiarity and confidence through consistent question practice.'],

  [MessageCircle, 'Doubt-Solving Support', 'Ask questions, revisit tricky concepts and keep moving forward.'],

  [Users, 'Student-Focused Learning', 'A learning environment that makes room for different learning needs.'],

  [GraduationCap, 'Exam-Oriented Preparation', 'Connect your understanding to the assessments ahead.'],

]

function WhyChooseUs() { return <section className="why-section section-pad"><div className="container"><SectionHeading eyebrow="THE KCG APPROACH" title={<>A stronger foundation, <span>built together.</span></>} description="Good learning grows from clear explanations, consistent effort and the right support." align="center"/><div className="features-grid">{features.map(([Icon,title,desc],i) => <motion.article className="feature-card" key={title} {...reveal} transition={{duration:.5,delay:i*.06,ease}}><span className="feature-icon"><Icon size={21}/></span><span className="feature-number">0{i+1}</span><h3>{title}</h3><p>{desc}</p></motion.article>)}</div></div></section> }



const demoTestimonials = [

  { name: 'Student name placeholder', course: 'Class / course placeholder', text: 'Add a real student testimonial here after receiving their feedback and permission to share it.' },

  { name: 'Student name placeholder', course: 'Class / course placeholder', text: 'Share a student’s own words here. Testimonials will be published only with their permission.' },

  { name: 'Student name placeholder', course: 'Class / course placeholder', text: 'This space is ready for a genuine learning experience from a Kota Chemistry Gaya student.' },

]

function Testimonials() {

  const [slide, setSlide] = useState(0)

  const item = demoTestimonials[slide]

  return <section className="testimonial-section section-pad"><div className="container"><div className="testimonial-layout"><div className="testimonial-intro"><Eyebrow>STUDENT VOICES</Eyebrow><h2>Every learning story<br/>starts <span>somewhere.</span></h2><p>When our students are ready to share their experiences, we'll make room for their voices here.</p><div className="carousel-controls"><button aria-label="Previous testimonial" onClick={() => setSlide((slide + demoTestimonials.length - 1) % demoTestimonials.length)}><ChevronLeft size={19}/></button><span>0{slide+1} <i/> 0{demoTestimonials.length}</span><button aria-label="Next testimonial" onClick={() => setSlide((slide + 1) % demoTestimonials.length)}><ChevronRight size={19}/></button></div></div><motion.div className="testimonial-card" key={slide} initial={{opacity:0,x:14}} animate={{opacity:1,x:0}} transition={{duration:.35}}><div className="testimonial-top"><span className="quote-circle"><Quote size={18}/></span><span className="demo-badge"><i/> DEMO PLACEHOLDER</span></div><div className="testimonial-stars">✳ <span>✳</span> ✳ <span>✳</span> ✳</div><blockquote>“{item.text}”</blockquote><div className="testimonial-person"><div className="avatar-placeholder"><Users size={18}/></div><div><b>{item.name}</b><span>{item.course}</span></div><span className="testimonial-mark">KCG</span></div><span className="testimonial-disclaimer">Illustrative placeholder · Replace with verified student feedback</span></motion.div></div></div></section>

}



function Contact() {

  const [status, setStatus] = useState({ type: '', text: '' })

  const [busy, setBusy] = useState(false)

  const [form, setForm] = useState({ name: '', mobile: '', className: '', course: '', message: '' })

  useEffect(() => { const selectCourse = event => setForm(current => ({ ...current, course: event.detail })); window.addEventListener('select-course', selectCourse); return () => window.removeEventListener('select-course', selectCourse) }, [])

  const update = e => setForm({ ...form, [e.target.name]: e.target.value })

  const submit = e => {

    e.preventDefault(); setStatus({type:'',text:''})

    const mobileDigits = form.mobile.replace(/\D/g, '')
    if (!/^[+]?[-()\s\d]+$/.test(form.mobile.trim()) || mobileDigits.length < 10 || mobileDigits.length > 15) { setStatus({type:'error',text:'Please enter a valid mobile number (10–15 digits).'}); return }

    if (!form.name.trim()) { setStatus({type:'error',text:'Please enter the student name.'}); return }

    setBusy(true)

    const message = `Hello Kota Chemistry Gaya, I would like to enquire.\n\nStudent name: ${form.name}\nMobile: ${form.mobile}\nClass: ${form.className || 'Not specified'}\nCourse: ${form.course || 'Not specified'}\nMessage: ${form.message || '—'}`

    const opened = window.open(`https://wa.me/${institute.whatsapp}?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer')

    setBusy(false)

    setStatus({type: opened ? 'success' : 'error', text: opened ? 'Your enquiry is ready in WhatsApp. Send it there to reach us.' : 'Your browser blocked the WhatsApp window. Please allow pop-ups or contact us by phone.'})

  }

  return <section className="contact-section section-pad" id="contact"><div className="contact-ornament"/><div className="container"><SectionHeading eyebrow="LET'S TALK CHEMISTRY" title={<>Your next step starts with <span>a conversation.</span></>} description="Have a question about classes or course options? We'd be glad to hear from you."/><div className="contact-layout"><motion.div className="contact-info" {...reveal}><div className="contact-info-head"><span className="contact-info-kicker">GET IN TOUCH</span><h3>We’re here to<br/>help you get started.</h3><p>Reach out and tell us what you’re looking for. We’ll help you find the right next step.</p></div><div className="contact-details"><a href={institute.phoneHref}><span><Phone size={17}/></span><div><small>CALL US</small><b>{institute.phone}</b></div><ArrowUpRight size={15}/></a><div><span><GraduationCap size={17}/></span><div><small>FACULTY</small><b>Kota Chemistry by RP Yadaw Sir</b></div></div></div><a className="whatsapp-button" href={`https://wa.me/${institute.whatsapp}`} target="_blank" rel="noreferrer"><MessageCircle size={17}/> Chat with us on WhatsApp <ArrowUpRight size={15}/></a><div className="contact-social"><span>FOLLOW ALONG</span><SocialLinks light/></div></motion.div><motion.div className="contact-form-wrap" {...reveal}><div className="form-heading"><div><span>ENQUIRY FORM</span><h3>How can we help?</h3></div><div className="form-sparkle"><Send size={19}/></div></div><form onSubmit={submit} noValidate><div className="form-row"><label>Student name<input name="name" value={form.name} onChange={update} placeholder="Your name" autoComplete="name" required/></label><label>Mobile number<input name="mobile" value={form.mobile} onChange={update} placeholder="10-digit mobile number" inputMode="tel" autoComplete="tel" required/></label></div><div className="form-row"><label>Class<select name="className" value={form.className} onChange={update}><option value="">Select your class</option>{['Class 9','Class 10','Class 11','Class 12','Other'].map(x=><option key={x}>{x}</option>)}</select></label><label>Course interested in<select id="course-interest" name="course" value={form.course} onChange={update}><option value="">Choose a course</option>{courses.map(x=><option key={x.title}>{x.title}</option>)}</select></label></div><label>Message<textarea name="message" value={form.message} onChange={update} placeholder="Tell us a little about what you need..." rows="4"/></label>{status.text && <div className={`form-status ${status.type}`} role="status">{status.type === 'success' ? <CheckCircle2 size={17}/> : <CircleHelp size={17}/>}<span>{status.text}</span></div>}<button className="button button-blue form-submit" disabled={busy} type="submit">{busy ? 'Preparing…' : 'Send Enquiry'} <ArrowRight size={16}/></button><p className="form-privacy"><MessageCircle size={13}/> This form opens a pre-filled WhatsApp message. Nothing is stored on this website.</p></form></motion.div></div><div className="branch-grid">{institute.branches.map((branch, index) => <motion.article className="branch-card" key={branch.name} {...reveal}><div className="branch-card-head"><span><MapPin size={18}/></span><h3>{branch.name}</h3></div><p>{branch.address}</p><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(branch.mapQuery)}`} target="_blank" rel="noreferrer">View location on Google Maps <ArrowUpRight size={14}/></a></motion.article>)}</div></div></section>

}



function Footer() {

  return <footer className="footer"><div className="footer-top container"><div className="footer-brand-col"><Brand light/><p>Making Chemistry Easy, Interesting & Conceptual.<br/>Kota Chemistry by RP Yadaw Sir.</p><SocialLinks light/></div><div className="footer-col"><span className="footer-heading">EXPLORE</span><a href="#about">About us</a><a href="#faculty">Our faculty</a><a href="#courses">Our courses</a><a href="#achievements">Student stories</a><a href="#contact">Get in touch</a></div><div className="footer-col"><span className="footer-heading">OUR COURSES</span>{courses.slice(0,4).map(c=><a key={c.title} href="#courses">{c.title}</a>)}</div><div className="footer-col footer-contact"><span className="footer-heading">SAY HELLO</span><a href={institute.phoneHref}><Phone size={15}/>{institute.phone}</a><a href={`https://wa.me/${institute.whatsapp}`} target="_blank" rel="noreferrer"><MessageCircle size={15}/>WhatsApp enquiry</a>{institute.branches.map(branch => <span key={branch.name}><MapPin size={15}/>{branch.name}: {branch.address}</span>)}</div></div><div className="footer-bottom container"><span>© 2026 Kota Chemistry Gaya. All Rights Reserved.</span><span>MADE FOR CURIOUS MINDS <i>✳</i></span><a href="#home">BACK TO TOP ↑</a></div></footer>

}



export default function App() {

  useEffect(() => { document.documentElement.style.scrollBehavior = 'smooth' }, [])

  return <><Navbar/><main><Hero/><About/><Faculty/><Courses/><Achievements/><WhyChooseUs/><Testimonials/><Contact/></main><Footer/></>

}
